import json
import boto3

def lambda_handler(event, context):
    # Database
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Player_Profiles')
    # USERID
    userid = event["queryStringParameters"]["USERID"];
    
    response = table.get_item(Key={'UserID': userid})

    return {
            'statusCode': 200,
            'body' : json.dumps(response['Item']['ELO'])
    }
    
    # return {
    #    'statusCode': 200,
    #    'body': json.dumps('Hello from Lambda!')
    #}
