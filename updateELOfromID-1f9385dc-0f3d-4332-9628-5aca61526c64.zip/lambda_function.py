import json
import boto3

def lambda_handler(event, context):
    # TODO implement
    # Database
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Player_Profiles')
    # USERID
    userid = event["queryStringParameters"]["USERID"];
    elo = event["queryStringParameters"]["ELO"];
    
    response = table.update_item(
        Key = {'UserID': userid},
        UpdateExpression="SET #ELO=:e",
        ExpressionAttributeValues={':e' : elo},
        ExpressionAttributeNames={'#ELO': 'ELO' },
        ReturnValues= "UPDATED_NEW")

    return {
            'statusCode': 200,
            'body' : json.dumps("Updated Player")
    }
